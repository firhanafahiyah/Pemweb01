from Gempa import *

Banten = Gempa('1,2')
Palu = Gempa('6,1')
Cianjur = Gempa('5,6')
Jayapura = Gempa('3,3')
Garut= Gempa('4,0')

dampak()