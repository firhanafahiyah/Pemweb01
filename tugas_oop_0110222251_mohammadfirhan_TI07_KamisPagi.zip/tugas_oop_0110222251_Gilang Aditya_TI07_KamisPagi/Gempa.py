class Gempa:
    lokasi = 'Banten','Palu','Cianjur','Jayapura','Garut'
    skala = '1,2','6,1','5,6','3,3','4,0'
    
    def _init_(self, lok, skala):
        self.lokasi = lok
        self.skala = skala
        
dampak = int(input('Masukan Skala Gempa di Lokasi Anda : '))

if dampak <= 2:
  print('Dampak Gempa Tidak Akan Terasa')
elif dampak <= 4:
  print('Dampak Gempa Bangunan Bisa Mengakibatkan Bangunan Retak-Retak')
elif dampak <= 6:
  print('Dampak Gempa Bisa Mengakibatkan Bangunan Rubuh')
else:
  print('Dampak Gempa Bisa Mengakibatkan Bangunan Rubuh dan Berpotensi Tsunami Harap Evakuasi Diri Anda!')
    